import React from 'react'
import { useAuthContext } from '../../../context/AuthContext'

export default function Contact() {

    return (
        <>
            <h1 className="text-center py-5 ">WElcome To Contact Page</h1>
            <h1 className="text-center py-5">Owner's Email : inamabdullah58@gmail.com  </h1>
        </>
    )
}
