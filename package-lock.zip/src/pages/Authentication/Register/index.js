import React from 'react'
import Register from './Register'

export default function index() {
    return (
        <>
            <Register />
        </>
    )
}
